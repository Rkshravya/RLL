import { Component, DoCheck, OnInit } from '@angular/core';
import { User } from '../user';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit,DoCheck {
name:any;
  user : User=new User();

  constructor() { }
  ngDoCheck(): void {
    //check if local storage "user" is not null, then logged in. else, not logged in
    this.name=localStorage.getItem("userName");
     var str = localStorage.getItem("user");
    console.log(str);
    if(str!=null)
    {
      this.user = <User><any>JSON.parse(str);
    }
    
    var name:string;;
    // if(str==null)
    // {
    //  // alert("Please Login to access the services");
    // //  this.router.navigateByUrl('/(col3:login)');
    // }
    if(str!=null)
    {
      name=this.user.userName;
    }


  }

  ngOnInit(): void {
  }

}
