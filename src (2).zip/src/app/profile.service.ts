import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  url:string='http://localhost:8080/user/';

  constructor(private http:HttpClient) {

   }
   findUserByUserName(userName:string)
  {
    return this.http.get(this.url+userName);
  }
}
