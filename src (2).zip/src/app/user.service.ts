import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  url:string='http://localhost:8080/user/';

  constructor(private http:HttpClient) { }

  addUser(user:any)
  {
    return this.http.post(this.url,user);
  }

  modifyUser(user:any)
  {
    return this.http.put(this.url,user);
  }
  removeUser(userName:string)
  {
    return this.http.delete(this.url+userName);
  }
  validateLogin(formData:any)
  {
    return this.http.post(this.url+"login",formData);
  }

  generateOtp(emailAddress:string)
  {
    return this.http.post(this.url+"otp",emailAddress);
  }
  method1()
  {
    const myObservable=new Observable(observer=>{
      setTimeout(()=>{
        observer.next([33,22,10,82,94,83,344]);
      });
    });
    return myObservable;
  }
}
