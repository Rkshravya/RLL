import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { AccountComponent } from './account/account.component';
import { AdminComponent } from './admin/admin.component';
import { BranchComponent } from './branch/branch.component';
import { ContactusComponent } from './contactus/contactus.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { PayeeComponent } from './payee/payee.component';
import { ProfileComponent } from './profile/profile.component';
import { SignupComponent } from './signup/signup.component';
import { TransferComponent } from './transfer/transfer.component';

const routes: Routes = [
  {path:'home',component:HomeComponent,outlet:'col3'},
  {path:'login',component:LoginComponent,outlet:'col3'},
  {path:'logout',component:LogoutComponent,outlet:'col3'},
{path:'signup',component:SignupComponent,outlet:'col3'},
{path:'contactus',component:ContactusComponent,outlet:'col3'},
{path:'branch',component:BranchComponent,outlet:'col3'},
{path:'account',component:AccountComponent,outlet:'col3'},
{path:'profile',component:ProfileComponent,outlet:'col3'},
{path:'payee',component:PayeeComponent,outlet:'col3'},
{path:'transfer',component:TransferComponent,outlet:'col3'},
{path:'admin',component:AdminComponent,outlet:'col3'},
{path:'aboutus',component:AboutUsComponent,outlet:'col3'}];











@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
