export class Payee {
     payeeId:string='';
     bankName:string='';

     acc_number:string='';

     userName:string='';
     payeeName:string='';

	
}
